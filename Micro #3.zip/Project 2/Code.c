/*******************************************************
This program was created by the
CodeWizardAVR V3.14 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 4/4/2025
Author  : 
Company : 
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/

#include <mega32.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
// Alphanumeric LCD functions
#include <alcd.h>

// Declare your global variables here
bool checkPass;
int dsCounter;
int menu;
bool push;
bool chosen;
int wrongPassTimer;
int sevSegNumber[16] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};


// External Interrupt 0 service routine   //Button 1
interrupt [EXT_INT0] void ext_int0_isr(void)
{
// Place your code here
    if (!checkPass)
        return;
    menu++;
    menu %= 3;
    if (menu == 0)
    {  
        lcd_clear();
        lcd_gotoxy (0, 0);
        lcd_putsf ("LED   <<\nBUZZER");
        return;
    }   
    if (menu == 1)
    { 
        lcd_clear();
        lcd_gotoxy (0, 0);
        lcd_putsf ("LED\nBUZZER<<");
        return;
    }
    if (menu == 2)
    {
        lcd_clear();
        lcd_gotoxy (0, 0);
        lcd_putsf ("RELAY <<");
        return; 
    }
}

// External Interrupt 1 service routine   //Button 2
interrupt [EXT_INT1] void ext_int1_isr(void)
{
// Place your code here
    if (!checkPass)
        return; 
    if (!push)
    {
        push = 1;
        return;
    }
    push = 0;
    chosen = ~chosen;
    if (!chosen)
    {   
        lcd_clear();
        lcd_gotoxy (0, 0);
        switch (menu)
        {
        case 0: 
            lcd_putsf ("LED   <<\nBUZZER"); 
            break;
        case 1: 
            lcd_putsf ("LED\nBUZZER<<"); 
            break;
        case 2: 
            lcd_putsf ("RELAY <<"); 
            break;
        }
        PORTC = 0x00;
        PORTA = 0x00;
        return;
    }
    if (menu == 0)  
    {        
        lcd_gotoxy (0, 0);
        lcd_clear();
        lcd_putsf (">>LED");
        PORTC = 0x01;
        PORTA = sevSegNumber[10]; 
    }
    if (menu == 1)
    {
        lcd_gotoxy (0, 0);
        lcd_clear();
        lcd_putsf (">>BUZZER");
        PORTC = 0x02;  
        PORTA = sevSegNumber[11]; 
    }    
    if (menu == 2)
    { 
        lcd_gotoxy (0, 0);
        lcd_clear();
        lcd_putsf (">>RELAY");
        PORTC = 0x04;   
        PORTA = sevSegNumber[12]; 
    }
    return;
}

// Timer 0 output compare interrupt service routine
interrupt [TIM0_COMP] void timer0_comp_isr(void)
{
// Place your code here
// Each counter = 0.01s
dsCounter++;
wrongPassTimer++;
}

void main(void)
{
// Declare your local variables here
int sevSegCounter = 0;
int password = 0;
int lastInp[4] = {-1, -1, -1, -1};
int inp = -1;

// Input/Output Ports initialization
// Port A initialization
// Function: Bit7=Out Bit6=Out Bit5=Out Bit4=Out Bit3=Out Bit2=Out Bit1=Out Bit0=Out 
DDRA=(1<<DDA7) | (1<<DDA6) | (1<<DDA5) | (1<<DDA4) | (1<<DDA3) | (1<<DDA2) | (1<<DDA1) | (1<<DDA0);
// State: Bit7=0 Bit6=0 Bit5=0 Bit4=0 Bit3=0 Bit2=0 Bit1=0 Bit0=0 
PORTA=(0<<PORTA7) | (0<<PORTA6) | (0<<PORTA5) | (0<<PORTA4) | (0<<PORTA3) | (0<<PORTA2) | (0<<PORTA1) | (0<<PORTA0);

// Port B initialization
// Function: Bit7=Out Bit6=Out Bit5=Out Bit4=Out Bit3=Out Bit2=Out Bit1=Out Bit0=Out 
DDRB=(1<<DDB7) | (1<<DDB6) | (1<<DDB5) | (1<<DDB4) | (1<<DDB3) | (1<<DDB2) | (1<<DDB1) | (1<<DDB0);
// State: Bit7=0 Bit6=0 Bit5=0 Bit4=0 Bit3=0 Bit2=0 Bit1=0 Bit0=0 
PORTB=(0<<PORTB7) | (0<<PORTB6) | (0<<PORTB5) | (0<<PORTB4) | (0<<PORTB3) | (0<<PORTB2) | (0<<PORTB1) | (0<<PORTB0);

// Port C initialization
// Function: Bit7=Out Bit6=Out Bit5=Out Bit4=Out Bit3=Out Bit2=Out Bit1=Out Bit0=Out 
DDRC=(1<<DDC7) | (1<<DDC6) | (1<<DDC5) | (1<<DDC4) | (1<<DDC3) | (1<<DDC2) | (1<<DDC1) | (1<<DDC0);
// State: Bit7=0 Bit6=0 Bit5=0 Bit4=0 Bit3=0 Bit2=0 Bit1=0 Bit0=0 
PORTC=(0<<PORTC7) | (0<<PORTC6) | (0<<PORTC5) | (0<<PORTC4) | (0<<PORTC3) | (0<<PORTC2) | (0<<PORTC1) | (0<<PORTC0);

// Port D initialization
// Function: Bit7=In Bit6=In Bit5=In Bit4=In Bit3=In Bit2=In Bit1=In Bit0=In 
DDRD=(0<<DDD7) | (0<<DDD6) | (0<<DDD5) | (0<<DDD4) | (0<<DDD3) | (0<<DDD2) | (0<<DDD1) | (0<<DDD0);
// State: Bit7=T Bit6=T Bit5=T Bit4=T Bit3=P Bit2=P Bit1=T Bit0=T 
PORTD=(0<<PORTD7) | (0<<PORTD6) | (0<<PORTD5) | (0<<PORTD4) | (1<<PORTD3) | (1<<PORTD2) | (0<<PORTD1) | (0<<PORTD0);

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 7.813 kHz
// Mode: CTC top=OCR0
// OC0 output: Toggle on compare match
// Timer Period: 10.368 ms
// Output Pulse(s):
// OC0 Period: 20.736 ms Width: 10.368 ms
TCCR0=(0<<WGM00) | (0<<COM01) | (1<<COM00) | (1<<WGM01) | (1<<CS02) | (0<<CS01) | (1<<CS00);
TCNT0=0x00;
OCR0=0x50;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer1 Stopped
// Mode: Normal top=0xFFFF
// OC1A output: Disconnected
// OC1B output: Disconnected
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (0<<CS10);
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer2 Stopped
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=0<<AS2;
TCCR2=(0<<PWM2) | (0<<COM21) | (0<<COM20) | (0<<CTC2) | (0<<CS22) | (0<<CS21) | (0<<CS20);
TCNT2=0x00;
OCR2=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (1<<OCIE0) | (0<<TOIE0);

// External Interrupt(s) initialization
// INT0: On
// INT0 Mode: Low level
// INT1: On
// INT1 Mode: Any change
// INT2: Off
GICR|=(1<<INT1) | (1<<INT0) | (0<<INT2);
MCUCR=(0<<ISC11) | (1<<ISC10) | (0<<ISC01) | (0<<ISC00);
MCUCSR=(0<<ISC2);
GIFR=(1<<INTF1) | (1<<INTF0) | (0<<INTF2);

// USART initialization
// USART disabled
UCSRB=(0<<RXCIE) | (0<<TXCIE) | (0<<UDRIE) | (0<<RXEN) | (0<<TXEN) | (0<<UCSZ2) | (0<<RXB8) | (0<<TXB8);

// Analog Comparator initialization
// Analog Comparator: Off
// The Analog Comparator's positive input is
// connected to the AIN0 pin
// The Analog Comparator's negative input is
// connected to the AIN1 pin
ACSR=(1<<ACD) | (0<<ACBG) | (0<<ACO) | (0<<ACI) | (0<<ACIE) | (0<<ACIC) | (0<<ACIS1) | (0<<ACIS0);
SFIOR=(0<<ACME);

// ADC initialization
// ADC disabled
ADCSRA=(0<<ADEN) | (0<<ADSC) | (0<<ADATE) | (0<<ADIF) | (0<<ADIE) | (0<<ADPS2) | (0<<ADPS1) | (0<<ADPS0);

// SPI initialization
// SPI disabled
SPCR=(0<<SPIE) | (0<<SPE) | (0<<DORD) | (0<<MSTR) | (0<<CPOL) | (0<<CPHA) | (0<<SPR1) | (0<<SPR0);

// TWI initialization
// TWI disabled
TWCR=(0<<TWEA) | (0<<TWSTA) | (0<<TWSTO) | (0<<TWEN) | (0<<TWIE);

// Alphanumeric LCD initialization
// Connections are specified in the
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS - PORTB Bit 0
// RD - PORTB Bit 1
// EN - PORTB Bit 2
// D4 - PORTB Bit 4
// D5 - PORTB Bit 5
// D6 - PORTB Bit 6
// D7 - PORTB Bit 7
// Characters/line: 8
lcd_init(8);

// Global enable interrupts
#asm("sei")

lcd_gotoxy (0, 0); 
lcd_putsf ("Enter\nPassword");  //Password = *14# (On, 1, 4, =)

while (1)
    {    
        // Place your code here
        if (!checkPass)
        {                 
            PORTA = sevSegNumber[sevSegCounter];
            if (dsCounter == 12)  //Checked with a real clock!
            {
                dsCounter = 0;
                sevSegCounter++;
                sevSegCounter %= 16;
            }
            if (wrongPassTimer == 12)
            {    
                lcd_clear();
                lcd_gotoxy (0, 0); 
                lcd_putsf ("Enter\nPassword");
            } 
            if (lastInp[0] != PIND.4 || lastInp[1] != PIND.5 || lastInp[2] != PIND.6 || lastInp[3] != PIND.7)
            {
                lastInp[0] = PIND.4;
                lastInp[1] = PIND.5;
                lastInp[2] = PIND.6;
                lastInp[3] = PIND.7;
                inp++;
            } 
            else
                continue;
            switch (password)
            {
                case 0:
                    if (PIND.4 == 0 &&  PIND.5 == 0 && PIND.6 == 1 && PIND.7 == 1)  //12 = 1100    
                        password++;
                    else
                        password = 0; 
                    break;
                case 1:
                    if (PIND.4 == 0 &&  PIND.5 == 0 && PIND.6 == 0 && PIND.7 == 1)  //8 = 1000     
                        password++;
                    else 
                        password = 0;
                    break;
                case 2:
                    if (PIND.4 == 0 &&  PIND.5 == 0 && PIND.6 == 1 && PIND.7 == 0)  //4 = 0100     
                       password++;
                    else
                        password = 0;
                    break;
                case 3:
                    if (inp == 4 && PIND.4 == 0 &&  PIND.5 == 1 && PIND.6 == 1 && PIND.7 == 1)  //14 = 1110
                    {
                        lcd_clear();     
                        checkPass = 1;
                        PORTA = 0x00; 
                        dsCounter = 0;
                        lcd_gotoxy (0, 0); 
                        lcd_putsf ("Correct!");
                    }
                    else
                        password = 0;  
                    break;
                default:
                    break;
            }   
            if (inp == 4 && !checkPass)
            {            
                lcd_clear();
                lcd_gotoxy (0, 0); 
                lcd_putsf ("Wrong\nPass!");  
                wrongPassTimer = 0;
                inp = 0;
            }   
            continue;
        }  
        if (dsCounter < 20)  
            continue;
        else if (dsCounter == 20)
        {    
            lcd_clear();
            lcd_gotoxy (0, 0);
            lcd_putsf ("LED   <<\nBUZZER");
        }
        
        
    }
}
